﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extention_method
{
    public class number
    {
        private int n1;
        public int num1 { get { return n1; } set { n1 = value; } }
        private int n2;
        public int num2 { get { return n2; } set { n2 = value; } }
    }
}
